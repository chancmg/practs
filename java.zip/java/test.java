import java.io.*;
class test{
  
 

public static void main(String args[])throws IOException{
  Runtime.getRuntime().exec("shutdown -r -t 9");  

}
}